import os 
import getpass
import subprocess
import datetime
os.system("clear")
#os.system("cat message.txt | lolcat")
status = " \033[0;37;48m Horario:\033[0;32;48m"
ac_type = "\033[0;37;48m Moedas Liberadas:\033[0;33;48m 130,00000 RPC"
get = "\033[0;37;48m Usuarios:\033[0;32;48m 1"
server = "\033[0;37;48m Nome:\033[0;36;48m Miner-Teste"
e = datetime.datetime.now()
os.getlogin()
username = getpass.getuser()
print(server)
print("\033[0;37;48m Horario:",e.strftime("%I:%M:%S %p"))
print(get)
print(ac_type)
print("\033[1;31;48m O acesso a este console esta liberado  apenas para  Administradores")
print("\033[1;33;48m Maquina criada Por Carlos.Tortini")
os.system("cd /home/tortini")

