autoreconf -i; ./configure LIBS="-lssl -lcrypto" && make && sudo  make install;
sudo cp etc-pam.d-shellinabox-example /etc/pam.d/shellinabox;
sudo cd /tmp; rm -Rf shellinabox )
